const express = require('express');
const router = express.Router();
// const router = require('./routes/route');

const authorController = require("../controller/authorController")
const bookController = require("../controller/bookController")
const publisherController = require("../controller/publisherController")



router.post("/createAuthor", authorController.createAuthor)
router.post("/createPublisher",publisherController.createPublisher)
router.post("/createBook",bookController.createBook)

router.get("/getBooksData",bookController.getBooksData)

module.exports = router;