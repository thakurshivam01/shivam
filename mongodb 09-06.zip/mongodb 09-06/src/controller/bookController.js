const authorModel = require("../models/authorModel")
const bookModel= require("../models/bookModel")
const publishermodel=require("../models/Publishermodel")

// Q-3
const createBook= async function (req, res) {
    let book = req.body
    let authorIdFInder =req.body.author;
    console.log(authorIdFInder)
    let publisheridfinder =req.body.publisher;
    let findAuthor=await authorModel.findOne({_id:authorIdFinder});
    console.log(findAuthor)
    let findpublish=await publishermodel.findOne({_id:publisheridfinder})
      if(findAuthor===null){
          res.send("author Id Details Is Required");

      }
      if(findpublish===null){
      res.send("publish Id Details Is Required")
}
let bookCreated=await bookModel.create(bookData);
res.send({data: bookCreated});
}

// Q-4
const getBooksData= async function (req, res) {
    let books =await bookModel.find().populate([("author"),("publisher")])
    res.send({data: books})
}
// Q-5


module.exports.createBook= createBook
module.exports.getBooksData= getBooksData

